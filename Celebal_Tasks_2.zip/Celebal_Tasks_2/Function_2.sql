IF OBJECT_ID('dbo.FormatDate_YYYYMMDD', 'FN') IS NOT NULL
    DROP FUNCTION dbo.FormatDate_YYYYMMDD;
GO

CREATE FUNCTION dbo.FormatDate_YYYYMMDD (@InputDateTime DATETIME)
RETURNS VARCHAR(8)
AS
BEGIN
    RETURN CONVERT(VARCHAR(8), @InputDateTime, 112); -- Style 112 is YYYYMMDD
END;
GO -- Batch separator

SELECT dbo.FormatDate_YYYYMMDD(GETDATE()); -- Or any datetime value, e.g., '2025-06-01 14:00:00'