CREATE PROCEDURE DeleteOrderDetails
    @OrderID INT,
    @ProductID INT
AS
BEGIN
    -- Check if the combination of OrderID and ProductID exists
    IF EXISTS (
        SELECT * FROM [Order Details]
        WHERE OrderID = @OrderID AND ProductID = @ProductID
    )
    BEGIN
        -- Delete the matching record
        DELETE FROM [Order Details]
        WHERE OrderID = @OrderID AND ProductID = @ProductID;

        PRINT 'Record deleted successfully.';
    END
    ELSE
    BEGIN
        -- Print error message and return error code -1
        PRINT 'Invalid parameters: Either OrderID does not exist or ProductID does not exist in that order.';
        RETURN -1;
    END
END;
