CREATE PROCEDURE GetOrderDetails
    @OrderID INT
AS
BEGIN
    -- Check if any record exists with the given OrderID
    IF EXISTS (SELECT * FROM [Order Details] WHERE OrderID = @OrderID)
    BEGIN
        -- Return all records with the given OrderID
        SELECT * FROM [Order Details]
        WHERE OrderID = @OrderID;
    END
    ELSE
    BEGIN
        -- Print message and return 1 if no records found
        PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR(10)) + ' does not exist';
        RETURN 1;
    END
END;
