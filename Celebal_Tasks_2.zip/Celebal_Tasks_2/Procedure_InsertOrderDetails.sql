﻿CREATE PROCEDURE InsertOrderDetails
    @OrderID    INT,
    @ProductID  INT,
    @UnitPrice  MONEY   = NULL,
    @Quantity   INT,
    @Discount   FLOAT   = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActualUnitPrice MONEY;
    DECLARE @UnitsInStock     INT;
    DECLARE @ReorderLevel     INT;

    BEGIN TRY
        -- 1) Agar UnitPrice NULL hai, toh Products se pull karo
        IF @UnitPrice IS NULL
        BEGIN
            SELECT @ActualUnitPrice = UnitPrice
            FROM Products
            WHERE ProductID = @ProductID;

            IF @ActualUnitPrice IS NULL
            BEGIN
                RAISERROR('Invalid Product ID or UnitPrice not found.', 16, 1);
                RETURN;
            END
        END
        ELSE
        BEGIN
            SET @ActualUnitPrice = @UnitPrice;
        END

        -- 2) Stock & ReorderLevel check
        SELECT @UnitsInStock = UnitsInStock,
               @ReorderLevel = ReorderLevel
        FROM Products
        WHERE ProductID = @ProductID;

        IF @UnitsInStock IS NULL
        BEGIN
            RAISERROR('Invalid Product ID.', 16, 1);
            RETURN;
        END

        -- 3) Agar required quantity zyada hai stock se, abort
        IF @Quantity > @UnitsInStock
        BEGIN
            RAISERROR('Failed to place the order. Not enough stock available.', 16, 1);
            RETURN;
        END

        -- 4) Begin Transaction
        BEGIN TRANSACTION;

        -- 5) Insert order into [Order Details]
        INSERT INTO [Order Details](OrderID, ProductID, UnitPrice, Quantity, Discount)
        VALUES (@OrderID, @ProductID, @ActualUnitPrice, @Quantity, @Discount);

        -- 6) Check @@ROWCOUNT immediately
        IF @@ROWCOUNT = 0
        BEGIN
            RAISERROR('Failed to place the order. Please try again.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- 7) Update stock quantity
        UPDATE Products
        SET UnitsInStock = UnitsInStock - @Quantity
        WHERE ProductID = @ProductID;

        -- 8) Commit transaction
        COMMIT TRANSACTION;

        -- 9) Check updated stock for reorder‐level warning
        SELECT @UnitsInStock = UnitsInStock
        FROM Products
        WHERE ProductID = @ProductID;

        IF @UnitsInStock < @ReorderLevel
        BEGIN
            PRINT 'Warning: Stock level has dropped below the reorder level.';
        END

    END TRY
    BEGIN CATCH
        -- Agar koi bhi error aaya, rollback karo
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT      = ERROR_SEVERITY();
        DECLARE @ErrorState INT         = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
