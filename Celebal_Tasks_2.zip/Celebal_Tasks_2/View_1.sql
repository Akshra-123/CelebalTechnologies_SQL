CREATE VIEW vwCustomerOrders AS
SELECT 
    ISNULL(pp.FirstName + ' ' + pp.LastName, s.Name) AS CompanyName,
    soh.SalesOrderID AS OrderID,
    soh.OrderDate,
    sod.ProductID,
    prd.Name AS ProductName,
    sod.OrderQty AS Quantity,
    sod.UnitPrice,
    sod.OrderQty * sod.UnitPrice AS TotalPrice
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
JOIN 
    Production.Product AS prd ON sod.ProductID = prd.ProductID
JOIN 
    Sales.Customer AS c ON soh.CustomerID = c.CustomerID
LEFT JOIN 
    Person.Person AS pp ON c.PersonID = pp.BusinessEntityID
LEFT JOIN 
    Sales.Store AS s ON c.StoreID = s.BusinessEntityID;
