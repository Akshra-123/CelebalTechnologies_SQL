CREATE TRIGGER trg_CheckStockBeforeInsert
ON [Order Details]
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Products p ON i.ProductID = p.ProductID
        WHERE i.Quantity > p.UnitsInStock
    )
    BEGIN
        RAISERROR('Order cannot be placed for one or more items due to insufficient stock.', 16, 1);
    END
    ELSE
    BEGIN
        INSERT INTO [Order Details](OrderID, ProductID, UnitPrice, Quantity, Discount)
        SELECT OrderID, ProductID, UnitPrice, Quantity, Discount
        FROM INSERTED;

        UPDATE p
        SET p.UnitsInStock = p.UnitsInStock - i.Quantity
        FROM Products p
        JOIN INSERTED i ON p.ProductID = i.ProductID;
    END;
END;