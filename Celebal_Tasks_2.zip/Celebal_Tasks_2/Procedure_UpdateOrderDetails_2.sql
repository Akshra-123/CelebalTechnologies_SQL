DROP PROCEDURE IF EXISTS UpdateOrderDetails;
GO

CREATE PROCEDURE UpdateOrderDetails
    @OrderID    INT,
    @ProductID  INT,
    @UnitPrice  MONEY   = NULL,
    @Quantity   INT     = NULL,
    @Discount   FLOAT   = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldUnitPrice MONEY;
    DECLARE @OldQuantity INT;
    DECLARE @OldDiscount FLOAT;
    DECLARE @UnitsInStock INT;
    DECLARE @ReorderLevel INT;
    DECLARE @QuantityDifference INT;

    BEGIN TRY
        -- 1) Get current values
        SELECT
            @OldUnitPrice = od.UnitPrice,
            @OldQuantity = od.Quantity,
            @OldDiscount = od.Discount,
            @UnitsInStock = p.UnitsInStock,
            @ReorderLevel = p.ReorderLevel
        FROM [Order Details] od
        INNER JOIN Products p ON od.ProductID = p.ProductID
        WHERE od.OrderID = @OrderID AND od.ProductID = @ProductID;

        -- 2) Check if record exists
        IF @OldQuantity IS NULL
        BEGIN
            RAISERROR('Order detail for OrderID %d and ProductID %d not found.', 16, 1, @OrderID, @ProductID);
            RETURN;
        END

        -- 3) Check for NULL stock data
        IF @UnitsInStock IS NULL OR @ReorderLevel IS NULL
        BEGIN
            RAISERROR('Stock or reorder level not defined for ProductID %d.', 16, 1, @ProductID);
            RETURN;
        END

        -- 4) Apply ISNULL for optional params
        DECLARE @NewUnitPrice MONEY = ISNULL(@UnitPrice, @OldUnitPrice);
        DECLARE @NewQuantity INT = ISNULL(@Quantity, @OldQuantity);
        DECLARE @NewDiscount FLOAT = ISNULL(@Discount, @OldDiscount);

        SET @QuantityDifference = @NewQuantity - @OldQuantity;

        -- 5) Check stock availability
        IF @QuantityDifference > 0 AND @UnitsInStock < @QuantityDifference
        BEGIN
            RAISERROR('Failed to update order. Not enough additional stock available for ProductID %d.', 16, 1, @ProductID);
            RETURN;
        END

        -- 6) Begin transaction
        BEGIN TRANSACTION;

        -- 7) Update order details
        UPDATE [Order Details]
        SET
            UnitPrice = @NewUnitPrice,
            Quantity = @NewQuantity,
            Discount = @NewDiscount
        WHERE OrderID = @OrderID AND ProductID = @ProductID;

        IF @@ROWCOUNT = 0
        BEGIN
            RAISERROR('Failed to update the order details. Please try again.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- 8) Adjust stock if needed
        IF @QuantityDifference <> 0
        BEGIN
            UPDATE Products
            SET UnitsInStock = UnitsInStock - @QuantityDifference
            WHERE ProductID = @ProductID;
        END

        -- 9) Commit transaction
        COMMIT TRANSACTION;

        -- 10) Re-check UnitsInStock for reorder warning
        SELECT @UnitsInStock = UnitsInStock
        FROM Products
        WHERE ProductID = @ProductID;

        IF @UnitsInStock < @ReorderLevel
        BEGIN
            PRINT 'Warning: Stock level for ProductID ' + CAST(@ProductID AS NVARCHAR(10)) + ' has dropped below the reorder level.';
        END

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
