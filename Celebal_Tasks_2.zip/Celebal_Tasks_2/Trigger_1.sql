USE NORTHWND

CREATE TRIGGER trg_InsteadOfDeleteOrder
ON Orders
INSTEAD OF DELETE
AS
BEGIN
    -- Delete related order details first
    DELETE FROM [Order Details]
    WHERE OrderID IN (SELECT OrderID FROM DELETED)

    -- Then delete from Orders
    DELETE FROM Orders
    WHERE OrderID IN (SELECT OrderID FROM DELETED)
END;
